import { AgentStatusCard } from "@/components/agent-status-card"
import { EnergyChart } from "@/components/energy-chart"
import { GoalsList } from "@/components/goals-list"
import { HeartbeatMonitor } from "@/components/heartbeat-monitor"
import { PulseIndicator } from "@/components/pulse-indicator"
import { VitalityMetrics } from "@/components/vitality-metrics"
import { ConnectionHealth } from "@/components/connection-health"
import { RuminationTicker } from "@/components/rumination-ticker"
import { SemanticDensityMap } from "@/components/semantic-density-map"
import { InsightProgressBar } from "@/components/insight-progress-bar"
import { MemoryDepthChart } from "@/components/memory-depth-chart"
import { Brain } from "lucide-react"
import Link from "next/link"
import {
  mockAgentStatus,
  mockGoals,
  mockHeartbeatCycles,
  mockSystemVitality,
  mockMemoryDynamics,
  mockRuminations,
  mockInsightProgress,
} from "@/lib/mock-data"

export default async function DashboardPage() {
  const status = mockAgentStatus
  const goals = mockGoals
  const heartbeats = mockHeartbeatCycles
  const vitality = mockSystemVitality
  const memoryDynamics = mockMemoryDynamics
  const ruminations = mockRuminations
  const insightProgress = mockInsightProgress

  const memoryDistribution = [
    { type: "Generic", count: 423, color: "bg-purple-500" },
    { type: "Persona", count: 287, color: "bg-cyan-500" },
    { type: "Technical", count: 342, color: "bg-emerald-500" },
    { type: "Ethical", count: 195, color: "bg-blue-500" },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <Brain className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-foreground">Hexis Dashboard</h1>
              <p className="text-sm text-muted-foreground">Cognitive Architecture Monitor</p>
            </div>
          </div>
          <nav className="flex items-center gap-4">
            <button className="text-sm font-medium text-foreground hover:text-primary">Status</button>
            <Link href="/memory" className="text-sm text-muted-foreground hover:text-foreground">
              Memory
            </Link>
            <Link href="/chat" className="text-sm text-muted-foreground hover:text-foreground">
              Chat
            </Link>
            <Link href="/config" className="text-sm text-muted-foreground hover:text-foreground">
              Config
            </Link>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-6 space-y-6">
        <section className="space-y-4">
          <h2 className="text-lg font-semibold text-foreground">System Vitality</h2>
          <div className="flex items-center justify-between">
            <PulseIndicator status={vitality.pulse_status} />
            <div className="text-right">
              <div className="text-2xl font-mono font-bold text-foreground">#{vitality.heartbeat_index}</div>
              <div className="text-xs text-muted-foreground">Heartbeat Index</div>
            </div>
          </div>
          <VitalityMetrics
            hb_min={vitality.hb_min}
            mx_sec={vitality.mx_sec}
            uptime_seconds={vitality.uptime_seconds}
            api_latency_ms={vitality.api_latency_ms}
            loop_latency_ms={vitality.loop_latency_ms}
          />
        </section>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Left Column */}
          <div className="space-y-6 lg:col-span-2">
            <AgentStatusCard status={status} />

            <section className="space-y-4">
              <h2 className="text-lg font-semibold text-foreground">Memory Dynamics</h2>
              <div className="grid gap-4 md:grid-cols-2">
                <SemanticDensityMap clusters={memoryDynamics.semantic_density} />
                <div className="space-y-4">
                  <InsightProgressBar progress={insightProgress} />
                  <MemoryDepthChart data={memoryDistribution} />
                </div>
              </div>
            </section>

            <EnergyChart />
            <GoalsList goals={goals} />
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            <ConnectionHealth
              mcp_bridge={vitality.connection_health.mcp_bridge}
              postgres={vitality.connection_health.postgres}
              llm_api={vitality.connection_health.llm_api}
            />
            <HeartbeatMonitor cycles={heartbeats} />
            <RuminationTicker ruminations={ruminations} />
          </div>
        </div>
      </main>
    </div>
  )
}
