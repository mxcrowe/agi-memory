import { sql } from "./db"
import type {
  EpisodicMemory,
  SemanticMemory,
  MemoryCluster,
  WorldviewPrimitive,
  IdentityAspect,
  Concept,
} from "./db-types"

// Get agent status metrics
export async function getAgentStatus() {
  const [memoryStats] = await sql`
    SELECT 
      COUNT(*) FILTER (WHERE status = 'active') as active_memories,
      COUNT(*) FILTER (WHERE type = 'episodic') as episodic_count,
      COUNT(*) FILTER (WHERE type = 'semantic') as semantic_count,
      AVG(importance) as avg_importance,
      AVG(trust_level) as avg_trust
    FROM memories
  `

  const [clusterStats] = await sql`
    SELECT COUNT(*) as cluster_count
    FROM memory_clusters
  `

  const [recentActivity] = await sql`
    SELECT 
      MAX(created_at) as last_memory_created,
      MAX(last_accessed) as last_memory_accessed
    FROM memories
  `

  return {
    totalMemories: Number.parseInt(memoryStats.active_memories || "0"),
    episodicCount: Number.parseInt(memoryStats.episodic_count || "0"),
    semanticCount: Number.parseInt(memoryStats.semantic_count || "0"),
    clusterCount: Number.parseInt(clusterStats.cluster_count || "0"),
    avgImportance: Number.parseFloat(memoryStats.avg_importance || "0"),
    avgTrust: Number.parseFloat(memoryStats.avg_trust || "0"),
    lastActivity: recentActivity.last_memory_created || new Date().toISOString(),
  }
}

// Get recent episodic memories
export async function getRecentEpisodicMemories(limit = 20): Promise<EpisodicMemory[]> {
  const memories = await sql`
    SELECT 
      m.*,
      em.action_taken,
      em.context,
      em.result,
      em.emotional_valence,
      em.verification_status,
      em.event_time
    FROM memories m
    JOIN episodic_memories em ON m.id = em.memory_id
    WHERE m.status = 'active'
    ORDER BY m.created_at DESC
    LIMIT ${limit}
  `

  return memories as EpisodicMemory[]
}

// Get semantic memories
export async function getSemanticMemories(limit = 50): Promise<SemanticMemory[]> {
  const memories = await sql`
    SELECT 
      m.*,
      sm.confidence,
      sm.last_validated,
      sm.source_references,
      sm.contradictions,
      sm.category,
      sm.related_concepts
    FROM memories m
    JOIN semantic_memories sm ON m.id = sm.memory_id
    WHERE m.status = 'active'
    ORDER BY m.importance DESC, m.created_at DESC
    LIMIT ${limit}
  `

  return memories as SemanticMemory[]
}

// Get episodes with memory counts
export async function getEpisodes(limit = 10) {
  const episodes = await sql`
    SELECT 
      e.*,
      COUNT(em.memory_id) as memory_count
    FROM episodes e
    LEFT JOIN episode_memories em ON e.id = em.episode_id
    GROUP BY e.id
    ORDER BY e.started_at DESC
    LIMIT ${limit}
  `

  return episodes
}

// Get memory clusters
export async function getMemoryClusters(limit = 20): Promise<MemoryCluster[]> {
  const clusters = await sql`
    SELECT 
      mc.*,
      COUNT(mcm.memory_id) as member_count
    FROM memory_clusters mc
    LEFT JOIN memory_cluster_members mcm ON mc.id = mcm.cluster_id
    GROUP BY mc.id
    ORDER BY mc.importance_score DESC, mc.last_activated DESC NULLS LAST
    LIMIT ${limit}
  `

  return clusters as MemoryCluster[]
}

// Get worldview primitives
export async function getWorldviewPrimitives(): Promise<WorldviewPrimitive[]> {
  const worldview = await sql`
    SELECT *
    FROM worldview_primitives
    ORDER BY confidence DESC NULLS LAST, created_at DESC
  `

  return worldview as WorldviewPrimitive[]
}

// Get identity aspects
export async function getIdentityAspects(): Promise<IdentityAspect[]> {
  const aspects = await sql`
    SELECT *
    FROM identity_aspects
    ORDER BY stability DESC, aspect_type
  `

  return aspects as IdentityAspect[]
}

// Get concepts for knowledge graph
export async function getConcepts(limit = 100): Promise<Concept[]> {
  const concepts = await sql`
    SELECT 
      c.*,
      COUNT(mc.memory_id) as memory_count
    FROM concepts c
    LEFT JOIN memory_concepts mc ON c.id = mc.concept_id
    GROUP BY c.id
    ORDER BY memory_count DESC, c.name
    LIMIT ${limit}
  `

  return concepts as Concept[]
}

// Get memory dynamics for visualization
export async function getMemoryDynamics() {
  // Get memory creation over time (last 30 days)
  const creationTimeline = await sql`
    SELECT 
      DATE(created_at) as date,
      type,
      COUNT(*) as count
    FROM memories
    WHERE created_at > NOW() - INTERVAL '30 days'
    GROUP BY DATE(created_at), type
    ORDER BY date DESC
  `

  // Get cluster growth
  const clusterGrowth = await sql`
    SELECT 
      DATE(created_at) as date,
      cluster_type,
      COUNT(*) as count
    FROM memory_clusters
    WHERE created_at > NOW() - INTERVAL '30 days'
    GROUP BY DATE(created_at), cluster_type
    ORDER BY date DESC
  `

  // Get importance distribution
  const importanceDistribution = await sql`
    SELECT 
      CASE 
        WHEN importance < 0.2 THEN 'very_low'
        WHEN importance < 0.4 THEN 'low'
        WHEN importance < 0.6 THEN 'medium'
        WHEN importance < 0.8 THEN 'high'
        ELSE 'very_high'
      END as importance_level,
      COUNT(*) as count
    FROM memories
    WHERE status = 'active'
    GROUP BY importance_level
  `

  return {
    creationTimeline,
    clusterGrowth,
    importanceDistribution,
  }
}

// Get system vitality metrics
export async function getVitalityMetrics() {
  const [stats] = await sql`
    SELECT 
      COUNT(*) FILTER (WHERE status = 'active') as active_count,
      AVG(importance) as avg_importance,
      AVG(trust_level) as avg_trust,
      MAX(created_at) as last_created
    FROM memories
  `

  const [workingMemory] = await sql`
    SELECT COUNT(*) as count
    FROM working_memory
    WHERE expiry > NOW() OR expiry IS NULL
  `

  return {
    activeMemories: Number.parseInt(stats.active_count || "0"),
    avgImportance: Number.parseFloat(stats.avg_importance || "0"),
    avgTrust: Number.parseFloat(stats.avg_trust || "0"),
    workingMemoryCount: Number.parseInt(workingMemory.count || "0"),
    lastActivity: stats.last_created,
  }
}
