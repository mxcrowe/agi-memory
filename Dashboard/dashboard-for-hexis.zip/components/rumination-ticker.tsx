"use client"

import { useEffect, useRef, useState } from "react"
import { Card } from "@/components/ui/card"
import { Brain } from "lucide-react"
import type { RuminationEntry } from "@/lib/types"

interface RuminationTickerProps {
  ruminations: RuminationEntry[]
}

export function RuminationTicker({ ruminations }: RuminationTickerProps) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const [isPaused, setIsPaused] = useState(false)

  useEffect(() => {
    const element = scrollRef.current
    if (!element || isPaused) return

    const scroll = () => {
      if (element.scrollTop >= element.scrollHeight / 2) {
        element.scrollTop = 0
      } else {
        element.scrollTop += 1
      }
    }

    const interval = setInterval(scroll, 50)
    return () => clearInterval(interval)
  }, [isPaused])

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "reflection":
        return "text-purple-400"
      case "synthesis":
        return "text-cyan-400"
      case "planning":
        return "text-emerald-400"
      case "observation":
        return "text-blue-400"
      default:
        return "text-muted-foreground"
    }
  }

  const doubledRuminations = [...ruminations, ...ruminations]

  return (
    <Card className="p-4 bg-background/50 border-border/50 h-full">
      <div className="flex items-center gap-2 mb-3">
        <Brain className="h-4 w-4 text-purple-400" />
        <h3 className="text-sm font-semibold text-muted-foreground">Subconscious Reflection</h3>
      </div>
      <div
        ref={scrollRef}
        className="h-[400px] overflow-hidden space-y-3"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        {doubledRuminations.map((entry, index) => (
          <div key={`${entry.id}-${index}`} className="p-3 rounded-lg bg-background/30 border border-border/30">
            <div className="flex items-center gap-2 mb-1">
              <span className={`text-xs font-mono font-semibold ${getCategoryColor(entry.category)}`}>
                {entry.category.toUpperCase()}
              </span>
              <span className="text-xs text-muted-foreground">{new Date(entry.timestamp).toLocaleTimeString()}</span>
            </div>
            <p className="text-sm text-foreground leading-relaxed">{entry.content}</p>
          </div>
        ))}
      </div>
    </Card>
  )
}
