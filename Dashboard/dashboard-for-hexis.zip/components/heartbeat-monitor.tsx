"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Activity } from "lucide-react"
import type { HeartbeatCycle } from "@/lib/types"

interface HeartbeatMonitorProps {
  cycles: HeartbeatCycle[]
}

export function HeartbeatMonitor({ cycles }: HeartbeatMonitorProps) {
  const getPhaseColor = (phase: string) => {
    switch (phase) {
      case "observe":
        return "bg-chart-2 text-chart-2"
      case "orient":
        return "bg-chart-3 text-chart-3"
      case "decide":
        return "bg-chart-4 text-chart-4"
      case "act":
        return "bg-chart-5 text-chart-5"
      case "record":
        return "bg-chart-1 text-chart-1"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  return (
    <Card className="border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5" />
          Heartbeat Monitor
        </CardTitle>
        <CardDescription>Recent OODA loop cycles</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {cycles
          .slice(-5)
          .reverse()
          .map((cycle) => (
            <div key={cycle.id} className="flex items-center gap-3 rounded-lg border border-border/50 bg-card/50 p-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                <Activity className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-2">
                  <Badge className={getPhaseColor(cycle.phase)}>{cycle.phase}</Badge>
                  <span className="text-xs text-muted-foreground">
                    {new Date(cycle.timestamp).toLocaleTimeString()}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span>Duration: {cycle.duration_ms}ms</span>
                  <span>
                    Energy: {cycle.energy_before} → {cycle.energy_after}
                  </span>
                  <span>{cycle.actions_taken.length} actions</span>
                </div>
              </div>
            </div>
          ))}
      </CardContent>
    </Card>
  )
}
