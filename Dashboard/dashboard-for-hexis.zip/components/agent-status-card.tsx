"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Activity, Brain, Zap, Target } from "lucide-react"
import type { AgentStatus } from "@/lib/types"

interface AgentStatusCardProps {
  status: AgentStatus
}

export function AgentStatusCard({ status }: AgentStatusCardProps) {
  const energyPercent = (status.current_energy / status.max_energy) * 100
  const timeSinceHeartbeat = Math.floor((Date.now() - new Date(status.last_heartbeat).getTime()) / 1000)

  const getStatusColor = () => {
    switch (status.status) {
      case "active":
        return "bg-accent text-accent-foreground"
      case "idle":
        return "bg-muted text-muted-foreground"
      case "sleeping":
        return "bg-secondary text-secondary-foreground"
      case "error":
        return "bg-destructive text-destructive-foreground"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  return (
    <Card className="border-border/50">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">Agent Status</CardTitle>
        <Badge className={getStatusColor()}>{status.status}</Badge>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Agent ID</span>
            <span className="font-mono text-foreground">{status.agent_id}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Name</span>
            <span className="font-medium text-foreground">{status.name}</span>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-primary" />
              <span className="text-sm text-muted-foreground">Energy</span>
            </div>
            <span className="text-sm font-medium text-foreground">
              {status.current_energy} / {status.max_energy}
            </span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
            <div className="h-full bg-primary transition-all duration-500" style={{ width: `${energyPercent}%` }} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 pt-2">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Last Heartbeat</span>
            </div>
            <p className="text-sm font-medium text-foreground">{timeSinceHeartbeat}s ago</p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Target className="h-4 w-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Active Goals</span>
            </div>
            <p className="text-sm font-medium text-foreground">{status.active_goals}</p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Brain className="h-4 w-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Total Memories</span>
            </div>
            <p className="text-sm font-medium text-foreground">{status.total_memories.toLocaleString()}</p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Uptime</span>
            </div>
            <p className="text-sm font-medium text-foreground">{status.uptime_hours.toFixed(1)}h</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
